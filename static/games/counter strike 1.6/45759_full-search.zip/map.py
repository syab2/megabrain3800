import requests
from PIL import Image
from io import BytesIO


def show(ll, spn):
    map_api_server = "http://static-maps.yandex.ru/1.x/"
    params = {
        'll': ','.join([ll[0], ll[1]]),
        'spn': ','.join([spn, spn]),
        'l': 'map',
        'pt': ','.join([ll[0], ll[1]])
    }

    res = requests.get(map_api_server, params=params)

    Image.open(BytesIO(res.content)).show()
