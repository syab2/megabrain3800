import sys
import requests
from map import show


def get_coordinates(name):
    geocoder_request = f"http://geocode-maps.yandex.ru/1.x/?apikey=40d1649f-0493-4b70-98ba-98533de7710b&geocode={name}&format=json"
    response = requests.get(geocoder_request)
    if response:
        json_response = response.json()
        toponym = json_response["response"]["GeoObjectCollection"]["featureMember"][0]["GeoObject"]
        toponym_coodrinates = toponym["Point"]["pos"].split()
        return (toponym_coodrinates[0], toponym_coodrinates[1])


def main():
    toponym_to_find = input('Введите объект: ')
    spn = input('Введите масштабирование: ')

    if toponym_to_find:
        ll = get_coordinates(toponym_to_find)
        show(ll, spn)


if __name__ == '__main__':
    main()
